#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Qt6::DesignerComponentsPrivate" for configuration "None"
set_property(TARGET Qt6::DesignerComponentsPrivate APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(Qt6::DesignerComponentsPrivate PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libQt6DesignerComponents.so.6.8.2"
  IMPORTED_SONAME_NONE "libQt6DesignerComponents.so.6"
  )

list(APPEND _cmake_import_check_targets Qt6::DesignerComponentsPrivate )
list(APPEND _cmake_import_check_files_for_Qt6::DesignerComponentsPrivate "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libQt6DesignerComponents.so.6.8.2" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
