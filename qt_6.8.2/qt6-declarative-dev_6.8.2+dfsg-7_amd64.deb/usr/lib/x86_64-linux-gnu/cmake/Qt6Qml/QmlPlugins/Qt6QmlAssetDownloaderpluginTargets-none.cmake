#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Qt6::QmlAssetDownloaderplugin" for configuration "None"
set_property(TARGET Qt6::QmlAssetDownloaderplugin APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(Qt6::QmlAssetDownloaderplugin PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_NONE "CXX"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/qt6/qml/Assets/Downloader/libqmlassetdownloaderplugin.a"
  )

list(APPEND _cmake_import_check_targets Qt6::QmlAssetDownloaderplugin )
list(APPEND _cmake_import_check_files_for_Qt6::QmlAssetDownloaderplugin "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/qt6/qml/Assets/Downloader/libqmlassetdownloaderplugin.a" )

# Import target "Qt6::QmlAssetDownloaderplugin_init" for configuration "None"
set_property(TARGET Qt6::QmlAssetDownloaderplugin_init APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(Qt6::QmlAssetDownloaderplugin_init PROPERTIES
  IMPORTED_COMMON_LANGUAGE_RUNTIME_NONE ""
  IMPORTED_OBJECTS_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/qt6/qml/Assets/Downloader/objects-None/QmlAssetDownloaderplugin_init/QmlAssetDownloaderplugin_init.cpp.o"
  )

list(APPEND _cmake_import_check_targets Qt6::QmlAssetDownloaderplugin_init )
list(APPEND _cmake_import_check_files_for_Qt6::QmlAssetDownloaderplugin_init "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/qt6/qml/Assets/Downloader/objects-None/QmlAssetDownloaderplugin_init/QmlAssetDownloaderplugin_init.cpp.o" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
