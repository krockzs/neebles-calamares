QT_ARCH = x86_64
QT_BUILDABI = x86_64-little_endian-lp64
QT_LIBCPP_ABI_TAG = 
QT.global.enabled_features = version_tagging shared pkg-config signaling_nan zstd thread future concurrent dbus opensslv30 shared intelcet glibc_fortify_source trivial_auto_var_init_pattern stack_protector stack_clash_protection libstdcpp_assertions relro_now_linker shared reduce_exports openssl
QT.global.disabled_features = static cross_compile debug_and_release separate_debug_info appstore-compliant simulator_and_device rpath force_asserts framework c++20 c++2a c++2b reduce_relocations wasm-simd128 wasm-exceptions openssl-linked opensslv11
QT.global.disabled_features += release build_all
QT_CONFIG += shared reduce_exports openssl release
CONFIG +=  shared plugin_manifest intelcet glibc_fortify_source trivial_auto_var_init_pattern stack_protector stack_clash_protection libstdcpp_assertions relro_now_linker
QT_VERSION = 6.8.2
QT_MAJOR_VERSION = 6
QT_MINOR_VERSION = 8
QT_PATCH_VERSION = 2

QT_GCC_MAJOR_VERSION = 14
QT_GCC_MINOR_VERSION = 2
QT_GCC_PATCH_VERSION = 0
