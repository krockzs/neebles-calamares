#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Qt6::lconvert" for configuration "None"
set_property(TARGET Qt6::lconvert APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(Qt6::lconvert PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/qt6/bin/lconvert"
  )

list(APPEND _cmake_import_check_targets Qt6::lconvert )
list(APPEND _cmake_import_check_files_for_Qt6::lconvert "${_IMPORT_PREFIX}/lib/qt6/bin/lconvert" )

# Import target "Qt6::lprodump" for configuration "None"
set_property(TARGET Qt6::lprodump APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(Qt6::lprodump PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/qt6/libexec/lprodump"
  )

list(APPEND _cmake_import_check_targets Qt6::lprodump )
list(APPEND _cmake_import_check_files_for_Qt6::lprodump "${_IMPORT_PREFIX}/lib/qt6/libexec/lprodump" )

# Import target "Qt6::lrelease" for configuration "None"
set_property(TARGET Qt6::lrelease APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(Qt6::lrelease PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/qt6/bin/lrelease"
  )

list(APPEND _cmake_import_check_targets Qt6::lrelease )
list(APPEND _cmake_import_check_files_for_Qt6::lrelease "${_IMPORT_PREFIX}/lib/qt6/bin/lrelease" )

# Import target "Qt6::lrelease-pro" for configuration "None"
set_property(TARGET Qt6::lrelease-pro APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(Qt6::lrelease-pro PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/qt6/libexec/lrelease-pro"
  )

list(APPEND _cmake_import_check_targets Qt6::lrelease-pro )
list(APPEND _cmake_import_check_files_for_Qt6::lrelease-pro "${_IMPORT_PREFIX}/lib/qt6/libexec/lrelease-pro" )

# Import target "Qt6::lupdate" for configuration "None"
set_property(TARGET Qt6::lupdate APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(Qt6::lupdate PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/qt6/bin/lupdate"
  )

list(APPEND _cmake_import_check_targets Qt6::lupdate )
list(APPEND _cmake_import_check_files_for_Qt6::lupdate "${_IMPORT_PREFIX}/lib/qt6/bin/lupdate" )

# Import target "Qt6::lupdate-pro" for configuration "None"
set_property(TARGET Qt6::lupdate-pro APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(Qt6::lupdate-pro PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/qt6/libexec/lupdate-pro"
  )

list(APPEND _cmake_import_check_targets Qt6::lupdate-pro )
list(APPEND _cmake_import_check_files_for_Qt6::lupdate-pro "${_IMPORT_PREFIX}/lib/qt6/libexec/lupdate-pro" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
